# README

## Requisitos:
- docker

## Instalacion:
```
git clone git@gitlab.com:abee-logistics/demoapp.git
cd demoapp
docker compose up -d
docker compose exec app rails db:migrate
docker compose exec app rails db:seed
```


## Prueba:
`POST http://localhost:3000/organizations/1/orders`

como payload enviar el contenido del archivo `./public/shopify.jsbn`

## Para entrar a la consola
```
docker compose exec app rails c
```

## Explicacion simple

Un webhook nos envia un payload, en este caso el ejemplo es con shopify, procesamos los datos que nos interesan creando una orden y los items asociados, devolviendo un 200 en caso de que la creacion quede ok

## Objetivo

Despues de crear una orden es necesario comunicarse con un servicio externo, como ejemplo tomamos el de Falabella, para esto agregamos dos campos a la tabla `Organization` que representan el `user` y `api_key`, con estos datos es necesario hacer un `POST` al sistema de inventarios de Falabella y disminuir segun el `sku` y `quantity` que nos llega

## Condiciones

* El codigo de este servicio debe quedar aislado
* Se puede hacer un modulo dentro de la carpeta `/lib` para consumirlo durante el flujo
* Lo ideal sería crear un Engine y montarlo en el proyecto

