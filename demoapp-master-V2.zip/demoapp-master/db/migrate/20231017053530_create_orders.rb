class CreateOrders < ActiveRecord::Migration[7.0]
  def change
    create_table :orders do |t|
      t.integer :organization_id
      t.string :order_number
      t.string :client_name
      t.string :client_email

      t.timestamps
    end
  end
end
