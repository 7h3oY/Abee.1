module ApplicationHelper
  include Pagy::Frontend
end
