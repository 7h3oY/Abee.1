class OrdersController < ApplicationController
  skip_before_action :verify_authenticity_token, only: %i[create]

  def index
    @pagy, @records = pagy(Order.all)
  end

  def create
    organization = Organization.find_by!(id: params[:organization_id])
    service = ProcessShopifyService.new(params: params, organization: organization)
    service.create_all
    if service.errors.present?
      head :unprocessable_entity
    else
      head :ok
    end
  end
end
