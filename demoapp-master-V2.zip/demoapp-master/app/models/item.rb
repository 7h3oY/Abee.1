class Item < ApplicationRecord
  belongs_to :order
end
