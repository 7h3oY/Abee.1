class Organization < ApplicationRecord
  has_many :orders
end
