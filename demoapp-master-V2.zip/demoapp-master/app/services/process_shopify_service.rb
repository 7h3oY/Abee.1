class ProcessShopifyService
  attr_reader :errors

  def initialize(params:, organization:)
    @params = params
    @organization = organization
    @errors = []
  end

  def create_all
    create_order
    create_items
  end

  private

  def create_order
    @order = @organization.orders.build(
      order_number: @params[:id],
      client_name: @params.dig(:billing_address, :name),
      client_email: @params[:email]
    )
    @errors << @order.errors.messages unless @order.save
  end

  def create_items
    @params[:line_items].each do |item|
      item = @order.items.new(sku: item[:sku], quantity: item[:quantity])
      @errors << item.errors.messages unless item.save
    end
  end
end
